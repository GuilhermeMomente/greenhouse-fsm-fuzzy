
#pragma once

void inicializarAtuadores();
void ligarLuz();
void desligarLuz();
void ligarBomba();
void desligarBomba();
