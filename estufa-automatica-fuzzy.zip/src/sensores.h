
#pragma once

void inicializarSensor();
void atualizarSensor();
int getUmidade();
