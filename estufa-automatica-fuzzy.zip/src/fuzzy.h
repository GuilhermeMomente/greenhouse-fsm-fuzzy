
#pragma once

int calcularTempoBomba(int umidade);
void atualizarFuzzy();
