
# Estufa Automática com Controle Fuzzy

Projeto de nível engenharia para controle de iluminação e irrigação usando Arduino.

## Recursos
- Máquina de estados
- Controle fuzzy
- Código modular
- Pronto para ESP32

## Estrutura
Veja a pasta src/ para o código-fonte.
